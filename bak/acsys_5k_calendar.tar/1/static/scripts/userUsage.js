//google.setOnLoadCallback(drawTableUsage);
google.load('visualization', '1', { packages: ['table'] });

function drawTableUsage(username) {
    var data = new google.visualization.DataTable();
    data.addColumn('number', 'Week1');
    data.addColumn('number', 'Week2');
    data.addColumn('number', 'Week3');
	data.addColumn('number', 'Week4');
	data.addColumn('number', 'Week5');
    
	//7 days
	data.addRows(7);
	
	var userData = milesPeopleContainer[username];
	//logger(userData);
	for(var dataObj in userData)
	{
		//week 1
		data.setCell(0, 0, floatVal(userData['id-05012011']), "<span class='calendar_date_item'>May 1:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05012011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05012011'])), {'style': 'font-weight: normal;'});
		data.setCell(1, 0, floatVal(userData['id-05022011']), "<span class='calendar_date_item'>May 2:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05022011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05022011'])), {'style': 'font-weight: normal;'});
		data.setCell(2, 0, floatVal(userData['id-05032011']), "<span class='calendar_date_item'>May 3:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05032011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05032011'])), {'style': 'font-weight: normal;'});
		data.setCell(3, 0, floatVal(userData['id-05042011']), "<span class='calendar_date_item'>May 4:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05042011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05042011'])), {'style': 'font-weight: normal;'});
		data.setCell(4, 0, floatVal(userData['id-05052011']), "<span class='calendar_date_item'>May 5:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05052011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05052011'])), {'style': 'font-weight: normal;'});
		data.setCell(5, 0, floatVal(userData['id-05062011']), "<span class='calendar_date_item'>May 6:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05062011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05062011'])), {'style': 'font-weight: normal;'});
		data.setCell(6, 0, floatVal(userData['id-05072011']), "<span class='calendar_date_item'>May 7:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05072011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05072011'])), {'style': 'font-weight: normal;'});
		
		//week 2
		data.setCell(0, 1, floatVal(userData['id-05082011']), "<span class='calendar_date_item'>May 8:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05082011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05082011'])), {'style': 'font-weight: normal;'});
		data.setCell(1, 1, floatVal(userData['id-05092011']), "<span class='calendar_date_item'>May 9:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05092011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05092011'])), {'style': 'font-weight: normal;'});
		data.setCell(2, 1, floatVal(userData['id-05102011']), "<span class='calendar_date_item'>May 10:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05102011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05102011'])), {'style': 'font-weight: normal;'});
		data.setCell(3, 1, floatVal(userData['id-05142011']), "<span class='calendar_date_item'>May 11:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05112011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05142011'])), {'style': 'font-weight: normal;'});
		data.setCell(4, 1, floatVal(userData['id-05142011']), "<span class='calendar_date_item'>May 12:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05122011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05142011'])), {'style': 'font-weight: normal;'});
		data.setCell(5, 1, floatVal(userData['id-05142011']), "<span class='calendar_date_item'>May 13:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05132011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05142011'])), {'style': 'font-weight: normal;'});
		data.setCell(6, 1, floatVal(userData['id-05142011']), "<span class='calendar_date_item'>May 14:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05142011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05142011'])), {'style': 'font-weight: normal;'});
		
		//week 3
		data.setCell(0, 2, floatVal(userData['id-05152011']), "<span class='calendar_date_item'>May 15:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05152011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05152011'])), {'style': 'font-weight: normal;'});
		data.setCell(1, 2, floatVal(userData['id-05162011']), "<span class='calendar_date_item'>May 16:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05162011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05162011'])), {'style': 'font-weight: normal;'});
		data.setCell(2, 2, floatVal(userData['id-05172011']), "<span class='calendar_date_item'>May 17:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05172011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05172011'])), {'style': 'font-weight: normal;'});
		data.setCell(3, 2, floatVal(userData['id-05182011']), "<span class='calendar_date_item'>May 18:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05182011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05182011'])), {'style': 'font-weight: normal;'});
		data.setCell(4, 2, floatVal(userData['id-05192011']), "<span class='calendar_date_item'>May 19:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05192011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05192011'])), {'style': 'font-weight: normal;'});
		data.setCell(5, 2, floatVal(userData['id-05202011']), "<span class='calendar_date_item'>May 20:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05202011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05202011'])), {'style': 'font-weight: normal;'});
		data.setCell(6, 2, floatVal(userData['id-05212011']), "<span class='calendar_date_item'>May 21:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05212011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05212011'])), {'style': 'font-weight: normal;'});
		
		//week 4
		data.setCell(0, 3, floatVal(userData['id-05222011']), "<span class='calendar_date_item'>May 22:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05222011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05222011'])), {'style': 'font-weight: normal;'});
		data.setCell(1, 3, floatVal(userData['id-05232011']), "<span class='calendar_date_item'>May 23:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05232011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05232011'])), {'style': 'font-weight: normal;'});
		data.setCell(2, 3, floatVal(userData['id-05242011']), "<span class='calendar_date_item'>May 24:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05242011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05242011'])), {'style': 'font-weight: normal;'});
		data.setCell(3, 3, floatVal(userData['id-05252011']), "<span class='calendar_date_item'>May 25:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05252011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05252011'])), {'style': 'font-weight: normal;'});
		data.setCell(4, 3, floatVal(userData['id-05262011']), "<span class='calendar_date_item'>May 26:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05262011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05262011'])), {'style': 'font-weight: normal;'});
		data.setCell(5, 3, floatVal(userData['id-05272011']), "<span class='calendar_date_item'>May 27:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05272011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05272011'])), {'style': 'font-weight: normal;'});
		data.setCell(6, 3, floatVal(userData['id-05282011']), "<span class='calendar_date_item'>May 28:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05282011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05282011'])), {'style': 'font-weight: normal;'});
		
		//week 5
		data.setCell(0, 4, floatVal(userData['id-05292011']), "<span class='calendar_date_item'>May 29:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05292011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05292011'])), {'style': 'font-weight: normal;'});
		data.setCell(1, 4, floatVal(userData['id-05302011']), "<span class='calendar_date_item'>May 30:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05302011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05302011'])), {'style': 'font-weight: normal;'});
		data.setCell(2, 4, floatVal(userData['id-05312011']), "<span class='calendar_date_item'>May 31:</span> <span class='calendar_date_item_miles'>" + floatVal(userData['id-05312011']) + " miles</span>" + didMakeCheckMark(floatVal(userData['id-05312011'])), {'style': 'font-weight: normal;'});
		
	}
	 
	document.getElementById('user_usage_name').style.display = 'block';
    document.getElementById('user_usage_name').innerHTML = username;    
    
    var table = new google.visualization.Table(document.getElementById('user_usage_div'));
    table.draw(data, { showRowNumber: false, allowHtml: true });
    
    google.visualization.events.addListener(table, 'select', function() {
        var row = table.getSelection()[0].row;
        //logger('Selected Row: ' + data.getValue(row, 0));
      });

}

