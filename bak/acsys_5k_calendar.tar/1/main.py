#!/usr/bin/env python
#
import os
from datetime import datetime, date, time, timedelta
import datetime
import time
import calendar
from google.appengine.ext.webapp import template
from google.appengine.ext import webapp 
from google.appengine.ext.webapp import util
from google.appengine.ext import db
import base64
import Cookie
import logging
import urllib
import email.utils
import operator
#
# Acsys 5K: Built over a weekend by GlebP, 2011
#

def get_last_day_of_month(year, month):
	if (month == 12):
		year += 1
		month = 1
	else:
		month += 1
	return date(year, month, 1) - timedelta(1)

class PersonDB(db.Model):
	userid = db.StringProperty()
	recordid = db.StringProperty()
	milesno = db.FloatProperty()
	rundate = db.DateTimeProperty()
	addeddate = db.DateTimeProperty(auto_now_add=True)

class BasePage(webapp.RequestHandler):
	def get(self):
		#get username either from cookies or request
		userName = ''
		cookieName = "UserName5K"
		now = datetime.datetime.now()
		todayDateStr = "%s/%s/%s" % (now.month,now.day,now.year)#'05/11/2011'
		
		#url parameters
		monthParameter = ""
		monthParameterName = "m"
		if (monthParameterName in self.request.params):
			monthParameter = self.request.params[monthParameterName]
		
		#current month
		#see if we have date string in URL
		if (monthParameter != None):
			chunks = monthParameter.split('/')
			if (len(chunks) == 2):
				currentMonthDateObj = mkDateTime("%s-%s-01" % (chunks[1],chunks[0]))
			else:
				currentMonthDateObj = mkDateTime("%s-%s-01" % (now.year,now.month))
		else:
			currentMonthDateObj = mkDateTime("%s-%s-01" % (now.year,now.month))
		
		#prev month object
		if (currentMonthDateObj.month == 1):
			prevMonthDateObj = currentMonthDateObj.replace(year=currentMonthDateObj.year-1, month=12)
		else:
			prevMonthDateObj = currentMonthDateObj.replace(month=currentMonthDateObj.month-1)
		
		#next month object
		if (currentMonthDateObj.month == 12):
			nextMonthDateObj = currentMonthDateObj.replace(year=currentMonthDateObj.year+1, month=1)
		else:
			nextMonthDateObj = currentMonthDateObj.replace(month=currentMonthDateObj.month+1)#mkFirstOfMonth(currentMonthDateObj + datetime.timedelta(1*365/12))
		
		#self.response.out.write(currentMonthDateObj)
		#self.response.out.write(prevMonthDateObj)
		#self.response.out.write(nextMonthDateObj)
		
		#labels
		currentMonth = currentMonthDateObj.strftime('%B')
		nextMonth = nextMonthDateObj.strftime('%B')#next month
		prevMonth = prevMonthDateObj.strftime('%B')#prev month
		
		#ids for Prev/Next month links
		nextMonthID = nextMonthDateObj.strftime('%m/%Y')
		prevMonthID = prevMonthDateObj.strftime('%m/%Y')
		
		if (cookieName in self.request.cookies):
			#read cookie
			userName = self.request.cookies[cookieName]
		else:
			#get it from URL & set cookie (e.g. http://localhost:8080/?u=R2xlYlA%3D (GlebP) http://localhost:8080/?u=Sm9zaHVhUg%3D%3D%0A - JoshuaR
			userParam = 'u'
			if (userParam in self.request.params):
				userName = urllib.unquote(base64.decodestring(self.request.params[userParam]))
				logging.debug('base: setting new cookie: %s' % userName);
				userCookie = Cookie.BaseCookie()
				userCookie[cookieName] = userName
				expires = datetime.datetime.utcnow() + datetime.timedelta(days=30)
				timestamp = calendar.timegm(expires.utctimetuple())
				userCookie[cookieName]["expires"] = email.utils.formatdate(timestamp,localtime=False,usegmt=True)
				for morsel in userCookie.values():
					self.response.headers.add_header('Set-Cookie',morsel.OutputString(None))
			else:
				
				logging.error('base: missing user request parameter');
				self.response.out.write('Application Error: Invalid Username')
				return
		
		#validate that we have username
		if (userName == None or userName == ''):
			logging.error('base: unable to retrieve username from cookies or request parameters');
			self.response.out.write('Application Error: Invalid Username')
			return
				
		#get all entities
		userAllMilesContainer = {}
		userMilesContainer = {}
		allPersonRecords = db.GqlQuery("SELECT * FROM PersonDB WHERE rundate >= :1 AND rundate < :2", currentMonthDateObj, nextMonthDateObj)
		for person in allPersonRecords:
			#update user container
			if userMilesContainer.has_key(person.userid):
				#store total miles
				tmp = userMilesContainer[person.userid]
				newMiles = tmp + person.milesno
				userMilesContainer[person.userid] = newMiles
				
				#store daily miles
				tmpContainer = userAllMilesContainer[person.userid]
				tmpContainer[person.recordid] = person.milesno
				userAllMilesContainer[person.userid] = tmpContainer
			else:
				#store total miles
				miles = person.milesno
				userMilesContainer[person.userid] = miles
				
				#store daily miles
				tmpContainer = {}
				tmpContainer[person.recordid] = miles
				userAllMilesContainer[person.userid] = tmpContainer
		
		#JS for all miles
		userContainerJS = ''
		for key in userAllMilesContainer.keys():
			#go through record/miles container
			tmpUserContainer = userAllMilesContainer[key]
			tmpUserJS = ''
			for childKey in tmpUserContainer.keys():
				tmp = "'%s':'%s'," % (childKey, tmpUserContainer[childKey])
				tmpUserJS = "%s%s" % (tmpUserJS, tmp)
			tmpUserJS = tmpUserJS[0:len(tmpUserJS)-1]
			tmpUserMiles = "milesPeopleContainer['%s'] = {%s};\n" % (key, tmpUserJS)
			userContainerJS = "%s%s" % (userContainerJS, tmpUserMiles)
		
		#JS for total miles
		userTotalContainerJS = ''
		totalAcsysUsers = 0
		for key in userMilesContainer.keys():
			tmpUserMiles = "totalPeopleContainer['%s'] = %s;\n" % (key, userMilesContainer[key])
			userTotalContainerJS = "%s%s" % (userTotalContainerJS, tmpUserMiles)
			totalAcsysUsers = totalAcsysUsers + 1
		
		#ok, this is super ineffecient calling storage again...get all entities for this user
		personRecords = db.GqlQuery("SELECT * FROM PersonDB WHERE rundate >= :1 AND rundate < :2 AND userid='%s'" % userName, currentMonthDateObj, nextMonthDateObj)
		displayMilesDay = ''
		userMilesJS = ''
		totalAcsysMiles = 0.0
		for person in personRecords:
			#get total miles per day
			tmpMiles = "milesContainer['%s'] = %s;\n" % (person.recordid, person.milesno)
			userMilesJS = "%s%s" % (userMilesJS, tmpMiles)
			
			#display total miles per day
			dateObj = person.rundate.strftime('%A, %d')
			dayOfWeek = dateObj
			tmpHTML = "milesHTMLContainer['%s'] = ['%s', '%s'];\n" % (person.recordid, dayOfWeek, person.milesno)
			displayMilesDay = "%s%s" % (displayMilesDay, tmpHTML)
					
		#load custom template filters
		webapp.template.register_template_library('templatefilters')
		#display html template
		#userContainerJS = ''
		
		
		year = 2011
		month = 10
		first_day_of_month = date(year, month, 1)
		last_day_of_month = get_last_day_of_month(year, month)
		first_day_of_calendar = first_day_of_month - timedelta(first_day_of_month.weekday())
		last_day_of_calendar = last_day_of_month + timedelta(7 - last_day_of_month.weekday())
		
		month_cal = []
		week = []
		week_headers = []
		
		i = 0
		day = first_day_of_calendar
		while day <= last_day_of_calendar:
			if i < 7:
				week_headers.append(day)
			cal_day = {}
			if (day >= first_day_of_month and day <= last_day_of_month): 
				cal_day['day'] = day
			week.append(cal_day)
			if day.weekday() == 6:
				month_cal.append(week)
				week = []
			i += 1
			day += timedelta(1)
		
		week_container = []
		prevWeek = []
		for monthWeek in month_cal:
			w = monthWeek[0:len(monthWeek)-1]
			if len(prevWeek) > 0:
				sunday = prevWeek[-1]
				w.insert(0, sunday)
				week_container.append(w)
			else:
				week_container.append(w)
			prevWeek = monthWeek
		
		#check if last day is Sunday
		lastWeek = month_cal[-1]
		tmp = lastWeek[-1]
		if tmp and tmp['day'] == last_day_of_month:
			week_container.append(tmp)
		
		for m in week_container:
			self.response.out.write('%s<hr>' % m)
		
		template_values = {'today_date': todayDateStr, 'calendar': month_cal, 'headers': week_headers,
							'user_miles_js': userMilesJS, 
							'html_miles_js':  displayMilesDay,
							'acsys_users_miles_js': userTotalContainerJS,
							'acsys_users_total_js': totalAcsysUsers,
							'my_username': userName,
							'total_acsys_miles_js': totalAcsysMiles,
							'acsys_people_miles_js': userContainerJS,
							'current_month': currentMonth,
							'next_month': nextMonth,
							'previous_month': prevMonth,
							'next_month_id': nextMonthID,
							'prev_month_id': prevMonthID
							}
		path = os.path.join(os.path.dirname(__file__), 'templates')
		
		path = os.path.join(path, 'calendar.html')
		self.response.out.write(template.render(path, template_values))


#ajax call 
class SavePage(BasePage):
	title = ''
	def get(self):
		cookieName = "UserName5K"
		if cookieName in self.request.cookies:
			username = self.request.cookies[cookieName]
		recordid = self.request.get("id")
		milesno = self.request.get("mi")
		datestring = self.request.get("d")
		dateArr = datestring.split('/')
		runYear = 0
		runMonth = 0
		runDay = 0
		if (len(dateArr) == 3):
			runYear = int(int(dateArr[2]))
			runMonth = int(int(dateArr[0]))
			runDay = int(int(dateArr[1]))
		
		if (username and recordid and milesno and runYear > 0 and runMonth > 0 and runDay > 0):
			
			logging.debug('save: username=%s,recordid=%s,milesno=%s,date=%s' % (username,recordid,milesno,datestring))
			
			person_k = db.Key.from_path('PersonDB', '%s_%s' % (recordid,username))
			personRec = db.get(person_k)
			if (personRec != None):
				#self.response.out.write(personRec.milesno)
				logging.debug('save: updating existing instnace')
			else :
				personRec = PersonDB(key_name='%s_%s' % (recordid,username))
				logging.debug('save: creating new instnace')
				
			personRec.recordid = recordid
			personRec.userid = username
			personRec.milesno = eval(milesno)
			personRec.rundate = datetime.datetime(runYear, runMonth, runDay, 12,30)
			logging.debug('save: about to save')
			personRec.put()
			
			self.response.out.write('success')
		else:
			logging.error('save: invalid parameters')
			self.response.out.write('error: invalid parameter(s)')
		

def mkDateTime(dateString,strFormat="%Y-%m-%d"):
    # Expects "YYYY-MM-DD" string
    # returns a datetime object
    eSeconds = time.mktime(time.strptime(dateString,strFormat))
    return datetime.datetime.fromtimestamp(eSeconds)

def formatDate(dtDateTime,strFormat="%Y-%m-%d"):
    # format a datetime object as YYYY-MM-DD string and return
    return dtDateTime.strftime(strFormat)

def mkFirstOfMonth2(dtDateTime):
    #what is the first day of the current month
    ddays = int(dtDateTime.strftime("%d"))-1 #days to subtract to get to the 1st
    delta = datetime.timedelta(days= ddays)  #create a delta datetime object
    return dtDateTime - delta                #Subtract delta and return

def mkFirstOfMonth(dtDateTime):
    #what is the first day of the current month
    #format the year and month + 01 for the current datetime, then form it back
    #into a datetime object
    return mkDateTime(formatDate(dtDateTime,"%Y-%m-01"))

def mkLastOfMonth(dtDateTime):
    dYear = dtDateTime.strftime("%Y")        #get the year
    dMonth = str(int(dtDateTime.strftime("%m"))%12+1)#get next month, watch rollover
    dDay = "1"                               #first day of next month
    nextMonth = mkDateTime("%s-%s-%s"%(dYear,dMonth,dDay))#make a datetime obj for 1st of next month
    delta = datetime.timedelta(seconds=1)    #create a delta of 1 second
    return nextMonth - delta                 #subtract from nextMonth and return
		
def main():
    application = webapp.WSGIApplication([('/', BasePage), 
										('/save', SavePage)
										],
                                         debug=True)
    util.run_wsgi_app(application)


if __name__ == '__main__':
    main()
