google.setOnLoadCallback(drawChart2);
	function drawChart2() {
		var data = new google.visualization.DataTable();
		data.addColumn('string', 'Week');
		data.addColumn('number', 'Acsys Miles');
		data.addRows(getTotalParticipants());
		var counter = 0;
		for(var name in totalPeopleContainer)
		{
			data.setValue(counter, 0, name);
			data.setValue(counter, 1, totalPeopleContainer[name]);
			counter++;
		}
				
		var chart = new google.visualization.ColumnChart(document.getElementById('acsys_milesgraph_div'));
		chart.draw(data, { width: 960, height: 240, is3D: true, title: 'Acsys Tracker', colors:[{color:'#FF0000', darker:'#680000'}, {color:'cyan', darker:'deepskyblue'}] }); 
}